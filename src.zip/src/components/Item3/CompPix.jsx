

function GerarPix(){


    return(
        <div>
            
        </div>
    );
};

export default GerarPix;