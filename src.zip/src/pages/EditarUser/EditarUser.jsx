import Header from "../../components/Header/Header";
import "./EditarUser.css";

function EditarUser(){

    return(
        <div>
            <Header/>
        </div>
    )
}

export default EditarUser;