import Header from "../../components/Header/Header";
import "./EditarCartao.css";

function EditarCartao(){

    return(
        <div>
            <Header/>
        </div>
    )
}

export default EditarCartao;