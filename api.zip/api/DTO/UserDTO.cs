﻿namespace api.DTO
{
    public class UserDTO
    {
        public string nome { get; set; }
        public string email { get; set; }
        public string password { get; set; }
    }
}
